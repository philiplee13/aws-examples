import json
import time
import random
import logging

# Initialize the logger
logger = logging.getLogger()
logger.setLevel(logging.INFO) # Set the desired logging level

def lambda_handler(event, context):
    # Generate a fake payload
    payload = {
        "request_id": context.aws_request_id,
        "function_name": context.function_name,
        "timestamp": time.time(),
        "random_value": random.randint(1, 100)
    }

    # CloudWatch captures all `print()` statements as logEvents
    logger.info("🔥 Hello from test Lambda!") # shows as log
    logger.info(json.dumps({"users_processed": 42})) # shows as metric
    logger.info({"test": "value"}) # shows as log

    return {"status": "ok", "payload": payload}






