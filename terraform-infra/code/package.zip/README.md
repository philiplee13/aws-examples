## example code

- reads event and gets file key from `event`
- downloads and uploads that same file
- 3rd party libs are directly installed in directory
