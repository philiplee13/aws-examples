
import base64
import gzip
import json
import re
from io import BytesIO

def lambda_handler(event, context):
    output = []
    print(f"event is {event}")
    print(f"context is {context}")
    function_name = context.function_name

    for record in event["records"]:
        try:
            # Base64 decode
            compressed_bytes = base64.b64decode(record["data"])

            # Decompress gzip
            with gzip.GzipFile(fileobj=BytesIO(compressed_bytes)) as gz:
                decompressed = gz.read().decode("utf-8")

            # CloudWatch delivers a JSON with logEvents
            payload = json.loads(decompressed)

            logs = []
            metrics = []

            for log_event in payload.get("logEvents", []):
                message = log_event.get("message", "")

                # Match logger.* style: [LEVEL] timestamp reqId payload
                match = re.match(r"^\[\w+\]\s+\S+\s+\S+\s+(.*)", message)
                if match:
                    cleaned = match.group(1).strip()

                    # If payload is valid JSON → metric
                    try:
                        metrics.append(json.loads(cleaned))
                    except json.JSONDecodeError:
                        logs.append({"message": cleaned, "timestamp": log_event.get("timestamp")})

            # Build transformed object
            transformed_obj = {
                "function_name": function_name,
                "logs": logs,
                "metrics": metrics,
            }

            transformed = json.dumps(transformed_obj) + "\n"

            output.append({
                "recordId": record["recordId"],
                "result": "Ok",
                "data": base64.b64encode(transformed.encode("utf-8")).decode("utf-8")
            })

        except Exception as e:
            print(f"Transformer error: {e}")
            output.append({
                "recordId": record["recordId"],
                "result": "ProcessingFailed",
                "data": record["data"]
            })
    print(f"output is {output}")
    return {"records": output}


